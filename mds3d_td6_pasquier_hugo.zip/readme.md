
Les images des résultats obtenus sont disponibles dans le répertoire `images`. 

### Avancement 

Le passage des coordonnéds de textures au shader et le placage de texture fonctionne.
Cependant, le filtrage n'est pas implémenté.
